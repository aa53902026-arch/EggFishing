package com.pling.eggfishingauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class FishingAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_START = "com.pling.eggfishingauto.START"
        const val ACTION_STOP = "com.pling.eggfishingauto.STOP"
        private const val CHANNEL = "rare_egg"
    }
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var lastRareAt = 0L
    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val prefs = getSharedPreferences("settings", MODE_PRIVATE)
            val x = prefs.getFloat("x", 540f)
            val y = prefs.getFloat("y", 1200f)
            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
            dispatchGesture(gesture, null, null)
            handler.postDelayed(this, prefs.getLong("interval", 1500L).coerceAtLeast(500L))
        }
    }
    private val controlReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_START -> { if (!running) { running = true; handler.post(loop) } }
                ACTION_STOP -> { running = false; handler.removeCallbacks(loop) }
            }
        }
    }
    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter().apply { addAction(ACTION_START); addAction(ACTION_STOP) }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(controlReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(controlReceiver, filter)
        }
        createChannel()
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val texts = StringBuilder()
        collectText(root, texts)
        val content = texts.toString().lowercase()
        val keywords = listOf("rare", "legendary", "mythic", "secret", "희귀", "전설", "신화", "비밀", "jellynova")
        if (keywords.any { content.contains(it) } && System.currentTimeMillis() - lastRareAt > 15000) {
            lastRareAt = System.currentTimeMillis()
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") android.app.Notification.Builder(this)
            manager.notify(7, notification.setSmallIcon(android.R.drawable.star_big_on).setContentTitle("희귀 에그 감지!").setContentText("희귀 단어가 화면에서 감지됐어요. 자동 낚시는 계속됩니다.").setAutoCancel(true).build())
        }
        root.recycle()
    }
    private fun collectText(node: AccessibilityNodeInfo, out: StringBuilder) {
        node.text?.let { out.append(it).append(' ') }
        node.contentDescription?.let { out.append(it).append(' ') }
        for (i in 0 until node.childCount) node.getChild(i)?.let { child -> collectText(child, out); child.recycle() }
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "희귀 에그 알림", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
    override fun onInterrupt() { running = false; handler.removeCallbacks(loop) }
    override fun onDestroy() {
        running = false; handler.removeCallbacks(loop)
        try { unregisterReceiver(controlReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
