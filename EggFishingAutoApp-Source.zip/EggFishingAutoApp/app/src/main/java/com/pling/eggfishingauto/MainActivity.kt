package com.pling.eggfishingauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var intervalInput: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24); gravity = Gravity.TOP }
        root.addView(TextView(this).apply { text = "EggFishingAuto"; textSize = 28f })
        root.addView(TextView(this).apply { text = "화면 좌표를 지정해 반복 터치하고, 화면 접근성 텍스트에서 희귀 에그 단어를 알립니다.\n게임 화면과 버튼 위치에 맞게 좌표를 직접 설정해야 합니다."; textSize = 15f; setPadding(0, 12, 0, 20) })
        xInput = field(root, "터치 X 좌표", "540")
        yInput = field(root, "터치 Y 좌표", "1200")
        intervalInput = field(root, "터치 간격(ms, 최소 500)", "1500")
        root.addView(Button(this).apply { text = "접근성 권한 설정"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text = "START 자동 낚시"; setOnClickListener {
            val x = xInput.text.toString().toFloatOrNull() ?: 540f
            val y = yInput.text.toString().toFloatOrNull() ?: 1200f
            val ms = (intervalInput.text.toString().toLongOrNull() ?: 1500L).coerceAtLeast(500L)
            getSharedPreferences("settings", MODE_PRIVATE).edit().putFloat("x", x).putFloat("y", y).putLong("interval", ms).apply()
            sendBroadcast(Intent(FishingAccessibilityService.ACTION_START).setPackage(packageName))
            Toast.makeText(this@MainActivity, "시작 명령을 보냈어요. 게임 화면으로 이동하세요.", Toast.LENGTH_LONG).show()
        } })
        root.addView(Button(this).apply { text = "STOP 정지"; setOnClickListener { sendBroadcast(Intent(FishingAccessibilityService.ACTION_STOP).setPackage(packageName)); Toast.makeText(this@MainActivity, "정지 명령을 보냈어요.", Toast.LENGTH_SHORT).show() } })
        root.addView(TextView(this).apply { text = "희귀 단어 감지: rare, legendary, mythic, secret, 희귀, 전설, 신화, 비밀, Jellynova\n희귀 단어가 화면의 접근성 텍스트로 제공될 때 알림을 띄우며 낚시는 계속합니다. 이미지로만 표시되는 등 텍스트가 제공되지 않는 경우 감지하지 못할 수 있습니다."; textSize = 13f; setPadding(0, 18, 0, 0) })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun field(parent: LinearLayout, label: String, value: String): EditText {
        parent.addView(TextView(this).apply { text = label; textSize = 14f; setPadding(0, 8, 0, 0) })
        val edit = EditText(this).apply { setText(value); inputType = 2 }
        parent.addView(edit)
        return edit
    }
}
