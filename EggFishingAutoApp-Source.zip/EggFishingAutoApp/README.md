# EggFishingAuto (Android prototype)

This is a native Android/Kotlin prototype. It provides START/STOP controls, configurable repeated screen taps through an AccessibilityService, and notifications when rare-item keywords appear in accessibility text.

## Build on GitHub Actions
1. Upload the **contents** of this folder to the root of a GitHub repository (do not upload the enclosing folder as one nested directory).
2. Ensure `.github/workflows/build.yml` is present.
3. Open Actions and run **Build EggFishingAuto APK**.
4. Download the `EggFishingAuto-debug-apk` artifact from a successful run.

## Important limitations
- This prototype does not yet visually recognize the fishing gauge, moving fish, PERFECT indicator, or image-only rare egg artwork.
- Tap coordinates and interval are user-configured; defaults are examples and must be calibrated for the device/game screen.
- Rare notifications rely on text exposed by Android accessibility nodes. Image-only labels may not be detected.
- Enable the app's Accessibility Service in Android Settings before starting. Use only where permitted by the game's rules.
